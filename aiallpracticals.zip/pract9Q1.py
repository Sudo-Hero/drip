from sklearn.neighbors import KNeighborsClassifier
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
import seaborn as sn
import matplotlib.pyplot as plt

iris = load_iris()
x = iris.data
y = iris.target
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.3, random_state=1)
knn = KNeighborsClassifier(n_neighbors=10)
train = knn.fit(x_train, y_train)


print("Values for Target class: ", iris.target)
print("Size of the train data:", len(x_train))
print("Size of the test data:", len(x_test))
print(x_test)
print(y_test)
print("Predicted classes for the above testing Data:")

y_pred =train.predict(x_test)
print("Accuracy of the model:")
print(knn.score(x_test, y_test))
print("confusion matrix of model")
cm = confusion_matrix(y_test, y_pred)
print(cm)

plt.figure(figsize=(7,5))
sn.heatmap(cm, annot=True)
plt.xlabel('prediacted')
plt.ylabel('truth')
plt.show()
