graph = {
    "S": ["B", "A"],
    "B": ["C"],
    "C": ["G"],
    "A": ["G"],
}

def DFS(curNode, goal, graph, maxDepth):
    print("Checking for destination", curNode)

    if curNode == goal:
        print("Goal Found")
        return True

    if maxDepth <= 0:
        return False

    if curNode in graph: 
        for node in graph[curNode]:
            if DFS(node, goal, graph, maxDepth - 1):
                return True
    return False

def iterativeDDFS(curNode, goal, graph, maxDepth):
    for i in range(maxDepth):
        if DFS(curNode, goal, graph, i):
            return True
    return False

s = input("Enter source node: ")
g = input("Enter goal node: ")

if not iterativeDDFS(s, g, graph, 3):
    print("Path is Not Available")
else:
    print("A path exists")
