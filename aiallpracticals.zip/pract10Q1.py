import pandas as pd
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
import seaborn as sn
import matplotlib.pyplot as plt

csv = pd.read_csv('C:/SEMESTER-5/AI/PRACTICALS/Book1.csv')# Update with your file path
target_column = 'not.fully.paid'
Y = csv[target_column]
columns = ['purpose'] 
X = csv.drop(columns=[target_column])
X = pd.get_dummies(X, columns=columns, drop_first=True)  

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.3, random_state=1)
nb = GaussianNB()
train = nb.fit(X_train, Y_train)

print("Size of the Train data:", len(X_train))
print("Size of the Test data:", len(X_test))
print(X_test)
print(Y_test)
print("Predicted classes for the above testing data:")

Y_pred = train.predict(X_test)
print(Y_pred)
print("Accuracy of the model:")
print(nb.score(X_test, Y_test))
print("Confusion matrix of the model")
cm = confusion_matrix(Y_test, Y_pred)
print(cm)

plt.figure(figsize=(7, 5))
sn.heatmap(cm, annot=True)
plt.xlabel("Predicted")
plt.ylabel("Truth")
plt.show()
