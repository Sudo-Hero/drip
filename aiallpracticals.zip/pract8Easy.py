import numpy as np
from sklearn import datasets,model_selection
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB

#loading the iris
iris = datasets.load_iris()
#print iris data
print(iris)

#defining x for iris data
x = iris.data[:, 1:3]

#defining y for iris target
y = iris.target

#defining m1, m2 and m3
m1 = LogisticRegression(random_state=1)
m2 = RandomForestClassifier(random_state=1)
m3 = GaussianNB()

#printing the values of m1, m2 and m3 
print("Defining ",m1)
print("---------------------------")
print("Defining ",m2)
print("---------------------------")
print("Defining ",m3, "for Naive Bayes")

#defining Logistic Regression, Random Forest, Naive Bayes as lables
labels = ['Logistic Regression', 'Random Forest', 'Naive Bayes']

#for loop of m and label into m1, m2, m3 and labels
for m, label in zip([m1, m2, m3], labels):
    scores = model_selection.cross_val_score(m, x, y, cv=5, scoring='accuracy')
    print('------------------------')
#printing the scores as output
    #print(f"Accuracy for {label}: {scores.mean():.2f}")
    print("Accuracy for ",label, " is ",scores.mean())

