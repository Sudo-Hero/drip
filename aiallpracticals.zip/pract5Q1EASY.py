graph = {
    "O": ({"Z": 71, "S": 151}, 380),
    "Z": ({"O": 71, "A": 75}, 374),
    "A": ({"Z": 75, "S": 140, "T": 118}, 366),
    "T": ({"A": 75, "L": 140, "T": 111}, 329),
    "L": ({"T": 111, "M": 70}, 244),
    "M": ({"L": 70, "D": 75}, 241),
    "S": ({"O": 151, "F": 99, "R": 80, "A": 140}, 253),
    "F": ({"S": 99, "B": 211}, 176),
    "R": ({"S": 80, "P": 97, "C": 146}, 193),
    "B": ({"F": 211, "P": 101, "U": 85, "G": 90}, 0),
    "P": ({"R": 97, "C": 138, "B": 101}, 100),
    "C": ({"R": 146, "P": 138, "D": 120}, 160),
    "D": ({"M": 75, "C": 120}, 242),
    "U": ({"B": 85, "V": 142, "H": 98}, 80),
    "G": ({"B": 90}, 77),
    "V": ({"T": 92, "U": 142}, 199),
    "H": ({"U": 98, "E": 86}, 151),
    "I": ({"V": 92, "N": 87}, 2666),
    "E": ({"H": 86}, 161),
    "N": ({"I": 87}, 120)
}

def get_min(q):
    mn = min(q, key=lambda x: q[x][0] + q[x][1])
    return mn

def a_star(graph, prev, dst, path, pcost, q):
    if prev not in graph:
        return []
    print("Current node:", prev)
    for n in graph[prev][0]:
        if n not in path:
            q[n] = (graph[n][0][prev] + pcost, graph[n][1])
            print("Connected to", n, "with g(n) =", graph[n][0][prev], "and h(n) =", graph[n][1])    

    if dst in q:
        return path + [dst]
    next_node = get_min(q)

    if next_node:
        if next_node in q:
            del q[next_node]
        return a_star(graph, next_node, dst, path + [next_node], pcost + graph[next_node][0][prev], q)
    else:
        return []

source = input("Enter source : ")
dest = input("Enter goal : ")
path = a_star(graph, source, dest, [], 0, {source: (0, 0)})
if path:
    print("Shortest Path:", path)
else:
    print("Path not found")
