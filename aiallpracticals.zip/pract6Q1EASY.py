graph = {
    "O": ({"Z": 71, "S": 151}, 380),
    "Z": ({"O": 71, "A": 75}, 374),
    "A": ({"Z": 75, "S": 140, "T": 118}, 366),
    "T": ({"A": 75, "L": 140, "T": 111}, 329),
    "L": ({"T": 111, "M": 70}, 244),
    "M": ({"L": 70, "D": 75}, 241),
    "S": ({"O": 151, "F": 99, "R": 80, "A": 140}, 253),
    "F": ({"S": 99, "B": 211}, 176),
    "R": ({"S": 80, "P": 97, "C": 146}, 193),
    "B": ({"F": 211, "P": 101, "U": 85, "G": 90}, 0),
    "P": ({"R": 97, "C": 138, "B": 101}, 100),
    "C": ({"R": 146, "P": 138, "D": 120}, 160),
    "D": ({"M": 75, "C": 120}, 242),
    "U": ({"B": 85, "V": 142, "H": 98}, 80),
    "G": ({"B": 90}, 77),
    "V": ({"T": 92, "U": 142}, 199),
    "H": ({"U": 98, "E": 86}, 151),
    "I": ({"V": 92, "N": 87}, 2666),
    "E": ({"H": 86}, 161),
    "N": ({"I": 87}, 120)
}

def get_min(q):
    mn=min(q, key=q.get, default=None)
    return mn

def greedy_search_rec(graph, prev, dst, path, q):
    if prev not in graph:
        return []
    print("Connected nodes of current node", prev, "with h(n) values:")
    for n in graph[prev][0]:
        if n not in path:
            q[n] = graph[n][1]
            print(n, "->", q[n])

    while q:
        mn = get_min(q)
        print("Taking minimum h(n) vertex:", mn)
        if dst == mn:
            return path + [dst]
        del q[mn]
        new_path = greedy_search_rec(graph, mn, dst, path + [mn], q)        
        if new_path:
            return new_path
    return []

source = input("Enter source vertex: ")
dest = input("Enter destination vertex: ")
path = greedy_search_rec(graph, source, dest, [source], {})

if path:
    print("Shortest Path:", " -> ".join(path))
else:
    print("Path not found!")
