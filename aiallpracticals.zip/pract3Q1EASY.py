# DLS 
# DEPTH LIMIT SEARCH ROMANIAN MAP PROBLEM
adj_list = {
    "S": ["B", "A"],
    "B": ["C"],
    "C": ["G"],
    "A": ["G"],
}

def dls(node, goal, path, depth, max_depth):
    print('Current node is:', node)
    print('Testing for', goal, 'from', node)    
    path.append(node)

    if node == goal:
        print('Goal node found!')
        return path
    if depth >= max_depth:
        print('Maximum depth reached!')
    print('Expanding current node', node)
    print('--------------------------')

    for neighbor in adj_list.get(node, []):
        if neighbor not in path:
            result = dls(neighbor, goal, path, depth + 1, max_depth)
            return result
    path.pop()

s = input('Enter source node: ')
g = input('Enter the goal node: ')
max_depth = int(input('Enter the maximum depth limit: '))
print("---------------------------------")
path = []
output = dls(s, g, path, 0, max_depth)

if output:
    print('There exists a path from source to goal.')
    print('Path is:', ' -> '.join(output))
else:
    print('No path from source to goal in the given depth limit')
