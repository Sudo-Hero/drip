import pandas as pd
from sklearn import metrics
from sklearn.model_selection import train_test_split

csv = pd.read_csv("dtree2.csv")
col_names = ['Reservation', 'Raining', 'BadService', 'Satur', 'Result']
csv = pd.get_dummies(csv, columns=['Reservation'])
csv = csv.dropna()

feature_cols = ['Raining', 'BadService', 'Satur', 'Result']
X = csv[feature_cols]
y = csv['Result']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=1)
print(csv)
print("x train data: ", X_train)
print("y train data: ", y_train)
print("x test data: ", X_test)
print("y test data: ", y_test)

